Zachary Lindner
0975714
zlindner@uoguelph.ca
Assignment 3

# BONUS
I implemented the sex column for GEDCOM view, but didn't get the chance to implement family
size.