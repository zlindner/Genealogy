Zachary Lindner
0975714
zlindner@uoguelph.ca
Assignment 1 Resubmission
